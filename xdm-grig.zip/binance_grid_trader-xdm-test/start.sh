nohup python -u main.py > grid_nohup.out 2>&1 & echo $! > process.pid
