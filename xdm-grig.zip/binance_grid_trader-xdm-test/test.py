import requests
import time
import hmac
import hashlib
from enum import Enum
from threading import Lock

from gateway import BinanceSpotHttp, OrderStatus, OrderType, OrderSide
from utils import config
from utils import utility, round_to

import logging
from datetime import datetime

import json
from pathlib import Path
from decimal import Decimal


# 获取行情数据    https://api.binance.com/api/v3/ticker/price?symbol=ETHUSDT

if __name__ == '__main__':

    config.loads('./config.json')
    print(config.platform)
    # url = "https://testnet.binance.vision/api/v3/ticker/price?symbol=ETHUSDT"
    url = "https://testnet.binance.vision/api/v3/exchangeInfo"
    # url = "https://api.binance.com/api/v3/ticker/price?symbol=ETHUSDT"

    for i in range(5):
        response = requests.request(method='Get', url= url)
        pc = float(response.json().get('price',0))

        print(pc)

        # time.sleep(5)

    exit(1)