kill `cat process.pid`
